package ejercicio02;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Double Radio, Area, Perimetro;
		Double Pi = 3.14164862;
				
		Scanner scan = new Scanner(System.in);
		System.out.println("Digite el valor del radio del circulo:");
		Radio =scan.nextDouble();		
		
		Perimetro = 2 * Pi * Radio;
		
		Area = Pi * Radio  * Radio;
		
		
		System.out.println("El perimetro de la circunferencia es:");
		System.out.println(Perimetro);
		
		System.out.println("El área del circulo es:");
		System.out.println(Area);
		
	}
}
